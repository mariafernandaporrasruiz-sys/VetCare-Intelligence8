# VetCare Intelligence

VetCare Intelligence is a Java-based web application designed to manage veterinary clinical records for pets. The system allows users to register pet information, medical diagnoses, vaccines, next vaccination dates, veterinary follow-ups, and AI-generated recommendations.

The application runs locally in a web browser using a Java HTTP server and integrates the Gemini API to generate intelligent pet care recommendations.

## Project Objective

The main objective of this project is to demonstrate the use of Object-Oriented Programming principles in Java through a functional veterinary record management system with artificial intelligence integration.

## Main Features

- Register pet owner information
- Register pet clinical records
- Store vaccine information
- Register next vaccination dates
- Register next veterinary control dates
- Generate AI-based pet care recommendations
- Ask questions to an AI assistant specialized in pet care
- Store clinical records during the active session
- Display pet clinical history
- Validate that AI questions remain within the pet care domain

## Technologies Used

- Java
- Object-Oriented Programming
- Local Java HTTP Server
- HTML
- CSS
- Gemini API
- SQL
- GitHub
- Visual Studio Code

## Object-Oriented Programming Concepts Applied

### Encapsulation

The system uses private attributes and public getter methods to protect and access object data.

### Abstraction

The system separates responsibilities into different classes such as `Pet`, `Owner`, `Vaccine`, `MedicalRecord`, `AIService`, and `WebServer`.

### Modularity

Each class has a specific responsibility, which improves maintainability and code organization.

### Reusability

The model classes can be reused in different parts of the system, such as web forms, clinical records, patient records, and AI prompts.

### Interface

The project includes a repository interface to represent common CRUD operations.

## Main Classes

- `Main`
- `WebServer`
- `AIService`
- `Owner`
- `Pet`
- `Vaccine`
- `MedicalRecord`
- `Veterinarian`
- `Appointment`
- `PatientRecord`
- `VaccineSchedule`
- `CrudRepository`

## AI Integration

The system integrates the Gemini API to generate pet care recommendations based on clinical information entered by the user.

The AI assistant is designed to answer only questions related to:

- Pets
- Vaccines
- Veterinary appointments
- Diagnoses
- Treatments
- General pet care

Questions outside the pet care domain are rejected by the system.

## Database

The project includes a SQL script with tables for:

- Owners
- Pets
- Vaccines
- Medical records
- Appointments
- AI consultations

The database script is located in:

```text
database/vetcare_database.sql